module.exports = {
  extends: "handlebarlabs"
};